package com.internet_banking_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetBankingServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
