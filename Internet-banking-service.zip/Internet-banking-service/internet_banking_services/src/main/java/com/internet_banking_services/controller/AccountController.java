package com.internet_banking_services.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.internet_banking_services.dao.AccountDaoImpl;
import com.internet_banking_services.entity.AccountEntity;

@RestController
@RequestMapping("account")
public class AccountController {
	
	@Autowired
	private AccountDaoImpl al;
	
	private static final Logger logger = LoggerFactory.getLogger(AccountController.class); 
	
	@RequestMapping("getAccountList")
	public AccountEntity getAccountInfo(@RequestParam long userid) {
		
		AccountEntity acc=al.getAccountInfo(userid);
		logger.info("ACCOUNT Details");
		return acc;
	}
	
	 

}
