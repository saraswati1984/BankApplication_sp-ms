package com.internet_banking_services.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.internet_banking_services.dao.BeneficiaryDaoImpl;
import com.internet_banking_services.dao.TransactionDaoImpl;
import com.internet_banking_services.entity.BeneficiaryEntity;
import com.internet_banking_services.entity.TransactionEntity;

@RestController
@RequestMapping("txn")
public class TransactionController {

	
	@Autowired
	private TransactionDaoImpl al;
	
	private static final Logger logger = LoggerFactory.getLogger(TransactionController.class); 
	
	@RequestMapping("reqPay")
	public String reqPay(@RequestBody TransactionEntity txn) {
		String res=null;
		int i=al.payReq(txn);
		logger.info("Transaction Details");
		if(i>0) {
			res="Transaction done successfully";
		}
		return res;
	}
}
