package com.internet_banking_services.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.internet_banking_services.dao.LoginDaoImpl;
import com.internet_banking_services.entity.UserEntity;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("login")
public class LoginController {
	
	@Autowired
	private LoginDaoImpl ld;
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class); 
	
	@RequestMapping("registerUser")
	public String registerService(@RequestBody UserEntity user) {
		
	
		
		/*
		 * user=new UserEntity();
		 * 
		 * user.setAddress("mumbai1"); user.setUserName("roshan1");
		 * user.setUserId(12345); user.setPassword("1234561");
		 * user.setEmailId("roshan1@gmail.com");user.setMobile(1254878115);
		 */
		logger.info("LOGSTASH::::ELASTICSEARCH:::KIFANA");
		
		int cnt=ld.registerService(user);
		
		String res=null;
		
		
		if(cnt>0) {
			res  = "Register User Succesfully";
			logger.info("Registration Successfully");
		}
		
		
		return res;
	}
	
	@RequestMapping("loginUser")
	@HystrixCommand(fallbackMethod = "getFallBackLogin")
	public String loginService(UserEntity user) throws Exception{
		
		/*
		 * user=new UserEntity();
		 * 
		 * user.setPassword("123456"); user.setUserName("roshan");
		 */
		String res=null;
		int i=ld.loginService(user);
		
		if(i>0) {
		
		res  = "Logging Succesfully";
		logger.info("Logging Successfully");
		}
		else {
			throw new Exception();
		}
		return res;
		
	}
	
	public String getFallBackLogin() {
		
		return "Network or Login Issue...";
	}
	
	@RequestMapping("logout")
	public String logoutService (long userId) {
		
		
		return "Logout User Successfully";
	}
	
	
	
	

}
