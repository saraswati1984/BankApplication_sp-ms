package com.internet_banking_services.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.internet_banking_services.entity.AccountEntity;
import com.internet_banking_services.entity.UserEntity;

@Repository
public class AccountDao implements AccountDaoImpl {

	@Autowired
	private EntityManagerFactory emf;
	
	@SuppressWarnings("unchecked")
	@Override
	public AccountEntity getAccountInfo(long userId) {
		
		EntityManager em=emf.createEntityManager();
		 TypedQuery<AccountEntity> query = em.createQuery(
			        "SELECT * FROM AccountEntity u WHERE u.userId = '" + userId + "'",
			        AccountEntity.class);
		 
		 AccountEntity u=query.getSingleResult();
		 return u;
	}

}
