package com.internet_banking_services.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.internet_banking_services.entity.TransactionEntity;

@Repository
public class TransactionDao implements TransactionDaoImpl{

	@Autowired
	private EntityManagerFactory emf;
	@Override
	public int payReq(TransactionEntity txn) {
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();  
		em.persist(txn);       
		em.getTransaction().commit();  
		          
		 emf.close();  
		 em.close();
	     return 1;  
	}

}
