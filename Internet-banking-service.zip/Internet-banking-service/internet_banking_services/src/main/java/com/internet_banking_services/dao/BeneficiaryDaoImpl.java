package com.internet_banking_services.dao;

import com.internet_banking_services.entity.BeneficiaryEntity;

public interface BeneficiaryDaoImpl {

	public int addBeneficiary(BeneficiaryEntity ben) ;
}
