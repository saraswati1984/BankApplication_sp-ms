package com.internet_banking_services.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.internet_banking_services.entity.UserEntity;

@Repository
public class LoginDao implements LoginDaoImpl{
	
	@Autowired
	private EntityManagerFactory emf;

	@Override
	public int registerService(UserEntity user) {
		
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();  
		em.persist(user);       
		em.getTransaction().commit();  
		          
		 emf.close();  
		 em.close();
	     return 1;  
		
	}

	@Override
	public int loginService(UserEntity user) {
		int cnt=0;
		EntityManager em=emf.createEntityManager();
		 TypedQuery<UserEntity> query = em.createQuery(
			        "SELECT * FROM UserEntity u WHERE u.userName = '" + user.getUserName() + "'",
			        UserEntity.class);
		 
		 UserEntity u=query.getSingleResult();
		 
		 if(u.getUserName().equalsIgnoreCase(user.getUserName())) {
			 cnt=1;
		 }
		 
		 
		 
		return cnt;
	}

}
