package com.internet_banking_services.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.internet_banking_services.entity.BeneficiaryEntity;

@Repository
public class BeneficiaryDao implements BeneficiaryDaoImpl{

	@Autowired
	private EntityManagerFactory emf;

	@Override
	public int addBeneficiary(BeneficiaryEntity ben) {
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();  
		em.persist(ben);       
		em.getTransaction().commit();  
		          
		 emf.close();  
		 em.close();
	     return 1;  
	}

}
