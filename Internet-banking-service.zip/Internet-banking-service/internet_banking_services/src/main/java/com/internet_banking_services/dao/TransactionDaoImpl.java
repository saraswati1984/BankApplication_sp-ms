package com.internet_banking_services.dao;

import com.internet_banking_services.entity.TransactionEntity;

public interface TransactionDaoImpl {
	
	public int payReq(TransactionEntity txn) ;

}
