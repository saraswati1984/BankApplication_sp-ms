package com.internet_banking_services.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ben_tbl")
public class BeneficiaryEntity {
	
	@Id
	private long id;
	private long benId;
	private long userId;
	private String benAccount;
	private String benIfsc;
	private String benBankName;
	private String benBankBranch;
	private String benAccountType;
	
	enum BenAccountType 
	{ 
	    SAVING,CURRENT,SALARY; 
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getBenId() {
		return benId;
	}

	public void setBenId(long benId) {
		this.benId = benId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getBenAccount() {
		return benAccount;
	}

	public void setBenAccount(String benAccount) {
		this.benAccount = benAccount;
	}

	public String getBenIfsc() {
		return benIfsc;
	}

	public void setBenIfsc(String benIfsc) {
		this.benIfsc = benIfsc;
	}

	public String getBenBankName() {
		return benBankName;
	}

	public void setBenBankName(String benBankName) {
		this.benBankName = benBankName;
	}

	public String getBenBankBranch() {
		return benBankBranch;
	}

	public void setBenBankBranch(String benBankBranch) {
		this.benBankBranch = benBankBranch;
	}

	public String getBenAccountType() {
		return benAccountType;
	}

	public void setBenAccountType(String benAccountType) {
		this.benAccountType = benAccountType;
	} 
	
	
}
