package com.internet_banking_services.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.internet_banking_services.dao.BeneficiaryDaoImpl;
import com.internet_banking_services.entity.BeneficiaryEntity;

@RestController
@RequestMapping("ben")
public class BeneficiaryController {
	
	
	@Autowired
	private BeneficiaryDaoImpl al;
	
	private static final Logger logger = LoggerFactory.getLogger(BeneficiaryController.class); 
	
	@RequestMapping("addBen")
	public String addBeneficiary(@RequestBody BeneficiaryEntity ben) {
		String res=null;
		int i=al.addBeneficiary(ben);
		logger.info("Beneficiary Details");
		if(i>0) {
			res="Beneficiary add successfully";
		}
		return res;
	}
	
	
	public String deleteBeneficiary(BeneficiaryEntity ben) {
		
		
		return null;
	}
	
	public String modifyBeneficiary(BeneficiaryEntity ben) {
		
		
		return null;
	}
	
	public List<BeneficiaryEntity> getBeneficiaryList(long userId) {
		
		
		return null;
	}
	
	public List<BeneficiaryEntity> getAllBeneficiaryList() {
		
		
		return null;
	}


}
