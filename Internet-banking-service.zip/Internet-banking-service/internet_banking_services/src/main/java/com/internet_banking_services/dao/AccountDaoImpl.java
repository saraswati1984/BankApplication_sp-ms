package com.internet_banking_services.dao;

import com.internet_banking_services.entity.AccountEntity;

public interface AccountDaoImpl {

	public AccountEntity getAccountInfo(long userid);
}
