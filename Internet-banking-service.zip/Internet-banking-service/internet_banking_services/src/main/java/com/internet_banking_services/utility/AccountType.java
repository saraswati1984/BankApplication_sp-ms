package com.internet_banking_services.utility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.internet_banking_services.entity.AccountEntity;

@Component
@CacheConfig(cacheNames="AccountService")
public class AccountType {
	Logger logger = LogManager.getLogger(getClass());

	@Cacheable
	public AccountEntity getAccounType() {
		
		return new AccountEntity();
	}
}
