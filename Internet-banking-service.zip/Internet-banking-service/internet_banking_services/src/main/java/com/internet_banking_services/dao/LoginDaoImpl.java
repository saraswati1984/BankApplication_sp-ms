package com.internet_banking_services.dao;

import com.internet_banking_services.entity.UserEntity;

public interface LoginDaoImpl {
	
	public int registerService(UserEntity user) ;
	
	public int loginService(UserEntity user) ;

}
