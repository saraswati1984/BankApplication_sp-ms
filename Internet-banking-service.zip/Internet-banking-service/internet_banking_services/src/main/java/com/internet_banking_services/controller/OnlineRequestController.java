package com.internet_banking_services.controller;

import java.util.List;

import com.internet_banking_services.entity.OnlineRequestEntiry;

public class OnlineRequestController {
	
	
	public String registerRequest(OnlineRequestEntiry req) {
		
		return null;
	}
	
	public List<OnlineRequestEntiry> getListRequest(OnlineRequestEntiry req) {
		
		return null;
	}

}
