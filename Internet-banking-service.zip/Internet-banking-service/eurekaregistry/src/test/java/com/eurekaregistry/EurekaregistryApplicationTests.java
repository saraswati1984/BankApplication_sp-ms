package com.eurekaregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaregistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
