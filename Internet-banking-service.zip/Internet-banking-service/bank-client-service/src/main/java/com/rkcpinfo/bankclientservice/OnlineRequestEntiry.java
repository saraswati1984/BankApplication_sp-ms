package com.rkcpinfo.bankclientservice;


public class OnlineRequestEntiry {
	

	private long id;
	private long reqId;
	private String reqServiceName;
	private String reqServiceType;
	
	enum ReqServiceType 
	{ 
	    CARD , PIN , PASSBOOK ; 
	}
	
	private String desc;
	
	private String reqServiceDate;
	
	private String reqServiceStatus;
	
	
	enum ReqServiceStatus
	{ 
	    COMPLETED , INPROCESS , FAILED; 
	}
	
	private String finalReqDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getReqId() {
		return reqId;
	}

	public void setReqId(long reqId) {
		this.reqId = reqId;
	}

	public String getReqServiceName() {
		return reqServiceName;
	}

	public void setReqServiceName(String reqServiceName) {
		this.reqServiceName = reqServiceName;
	}

	public String getReqServiceType() {
		return reqServiceType;
	}

	public void setReqServiceType(String reqServiceType) {
		this.reqServiceType = reqServiceType;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getReqServiceDate() {
		return reqServiceDate;
	}

	public void setReqServiceDate(String reqServiceDate) {
		this.reqServiceDate = reqServiceDate;
	}

	public String getReqServiceStatus() {
		return reqServiceStatus;
	}

	public void setReqServiceStatus(String reqServiceStatus) {
		this.reqServiceStatus = reqServiceStatus;
	}

	public String getFinalReqDate() {
		return finalReqDate;
	}

	public void setFinalReqDate(String finalReqDate) {
		this.finalReqDate = finalReqDate;
	}
	
	
private long userId;
	
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
}
