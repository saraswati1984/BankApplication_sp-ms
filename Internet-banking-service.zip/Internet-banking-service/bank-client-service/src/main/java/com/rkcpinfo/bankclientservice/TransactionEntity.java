package com.rkcpinfo.bankclientservice;

public class TransactionEntity {
	
	private long id ;
	
	private long transactionId;
	
	private String transactionType;
	
	enum TransactionType 
	{ 
	    PAY, COLLECT; 
	} 
	
	private String transactionRefNo;
	
	private String transactionDate;
	
	private String transactionStatus;
	
	enum TransactionStatus
	{ 
	   SUCCESS ,FAILUER , PENDING
	} 
	
	private String payerAccount;
	private String payerIfsc;
	private String payerBankName;
	private String payerBankBranch;
	private String payerAccountType;
	
	private String payerAmount;
	
	private String payeeAccount;
	private String payeeIfsc;
	private String payeeBankName;
	private String payeeBankBranch;
	private String payeeAccountType;
	private String payeeAmount;
	
	private String transferType;
	
	enum TransferType 
	{ 
	    NEFT, RTGS , IMPS; 
	} 
	
	
	
	
	
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionRefNo() {
		return transactionRefNo;
	}
	public void setTransactionRefNo(String transactionRefNo) {
		this.transactionRefNo = transactionRefNo;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getPayerAccount() {
		return payerAccount;
	}
	public void setPayerAccount(String payerAccount) {
		this.payerAccount = payerAccount;
	}
	public String getPayerIfsc() {
		return payerIfsc;
	}
	public void setPayerIfsc(String payerIfsc) {
		this.payerIfsc = payerIfsc;
	}
	public String getPayerBankName() {
		return payerBankName;
	}
	public void setPayerBankName(String payerBankName) {
		this.payerBankName = payerBankName;
	}
	public String getPayerBankBranch() {
		return payerBankBranch;
	}
	public void setPayerBankBranch(String payerBankBranch) {
		this.payerBankBranch = payerBankBranch;
	}
	public String getPayerAccountType() {
		return payerAccountType;
	}
	public void setPayerAccountType(String payerAccountType) {
		this.payerAccountType = payerAccountType;
	}
	public String getPayerAmount() {
		return payerAmount;
	}
	public void setPayerAmount(String payerAmount) {
		this.payerAmount = payerAmount;
	}
	public String getPayeeAccount() {
		return payeeAccount;
	}
	public void setPayeeAccount(String payeeAccount) {
		this.payeeAccount = payeeAccount;
	}
	public String getPayeeIfsc() {
		return payeeIfsc;
	}
	public void setPayeeIfsc(String payeeIfsc) {
		this.payeeIfsc = payeeIfsc;
	}
	public String getPayeeBankName() {
		return payeeBankName;
	}
	public void setPayeeBankName(String payeeBankName) {
		this.payeeBankName = payeeBankName;
	}
	public String getPayeeBankBranch() {
		return payeeBankBranch;
	}
	public void setPayeeBankBranch(String payeeBankBranch) {
		this.payeeBankBranch = payeeBankBranch;
	}
	public String getPayeeAccountType() {
		return payeeAccountType;
	}
	public void setPayeeAccountType(String payeeAccountType) {
		this.payeeAccountType = payeeAccountType;
	}
	public String getPayeeAmount() {
		return payeeAmount;
	}
	public void setPayeeAmount(String payeeAmount) {
		this.payeeAmount = payeeAmount;
	}
	
private long userId;
	
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	

}
