package com.rkcpinfo.bankclientservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import java.util.ArrayList;
import java.util.List;

@RestController
public class BankClientController {

	  @Autowired
	  OAuth2RestTemplate restTemplate;
	  
	  @Autowired
	  private LoadBalancerClient cc;


	//  String url = "http://localhost:9091/internetbank/login/registerUser";

    @GetMapping("/register")
    public String register(@RequestBody UserEntity user) {
    	
    	ServiceInstance ss = cc.choose("internet-banking");
		String url = ss.getUri().toString();
		
		url = url + "/internetbank/login/register";
    
    	 ResponseEntity<String> resp = restTemplate.getForEntity(url,String.class,user);
         return resp.getBody();
    }
    
    @GetMapping("/account")
    public AccountEntity getAccountList(@RequestParam long userid) {
    	
    	ServiceInstance ss = cc.choose("internet-banking");
		String url = ss.getUri().toString();
		
		url = url + "/internetbank/account/getAccountList";
    
    	 ResponseEntity<AccountEntity> resp = restTemplate.getForEntity(url,AccountEntity.class,userid);
         return resp.getBody();
    }
    
    
    
    @GetMapping("/ben")
    public String addBeneficiary(@RequestBody BeneficiaryEntity ben) {
    	
    	ServiceInstance ss = cc.choose("internet-banking");
		String url = ss.getUri().toString();
		
		url = url + "/internetbank/ben/addBen";
    
    	 ResponseEntity<String> resp = restTemplate.getForEntity(url,String.class,ben);
         return resp.getBody();
    }

    @GetMapping("/txn")
    public String reqPay(@RequestBody TransactionEntity txn) {
    	
    	ServiceInstance ss = cc.choose("internet-banking");
		String url = ss.getUri().toString();
		
		url = url + "/internetbank/txn/reqPay";
    
    	 ResponseEntity<String> resp = restTemplate.getForEntity(url,String.class,txn);
         return resp.getBody();
    }
   
}
