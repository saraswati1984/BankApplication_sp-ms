package com.rkcpinfo.uizuulapp;


public class AccountEntity {
	
	
	private long id;
	private long accountId;
	private long userId;
	private String accountNo;
	private String accountStatus;
	
	enum AccountStatus 
	{ 
	    ACTIVE , DEACTIVE; 
	} 
	private String accountType;
	
	enum AccountType 
	{ 
	    SAVING,CURRENT,SALARY; 
	} 
	
	private String bankName;
	private String bankBranch;
	private String ifsc;
	private double currentAccountAmt;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankBranch() {
		return bankBranch;
	}
	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getCurrentAccountAmt() {
		return currentAccountAmt;
	}
	public void setCurrentAccountAmt(double currentAccountAmt) {
		this.currentAccountAmt = currentAccountAmt;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	

}
