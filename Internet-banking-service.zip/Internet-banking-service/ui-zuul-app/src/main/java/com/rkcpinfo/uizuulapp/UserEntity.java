package com.rkcpinfo.uizuulapp;





public class UserEntity {
	
	
	private long id;
	private long userId; // userId same as loginId
	private String userName;
	private int custmomerRefNumber;
	private int corporateId;
	private String password;
	private String address;
	private String emailId;
	private int mobile;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getCustmomerRefNumber() {
		return custmomerRefNumber;
	}
	public void setCustmomerRefNumber(int custmomerRefNumber) {
		this.custmomerRefNumber = custmomerRefNumber;
	}
	public int getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(int corporateId) {
		this.corporateId = corporateId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	
	
	

}
