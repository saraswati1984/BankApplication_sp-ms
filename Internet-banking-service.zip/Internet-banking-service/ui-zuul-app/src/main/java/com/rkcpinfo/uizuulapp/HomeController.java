package com.rkcpinfo.uizuulapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.rkcpinfo.uizuulapp.AccountEntity.AccountStatus;
import com.rkcpinfo.uizuulapp.AccountEntity.AccountType;
import com.rkcpinfo.uizuulapp.BeneficiaryEntity.BenAccountType;


@Controller
public class HomeController {

    @Autowired
    OAuth2RestTemplate restTemplate;

    @Value("${bankclient.api:http://localhost:9092/bankclient/register}")
    String bankclientApi;
    
    @Value("${bankclient.api:http://localhost:9092/bankclient/account}")
    String accountapi;
    
    @Value("${bankclient.api:http://localhost:9092/bankclient/txn}")
    String txnapi;
    
    @Value("${bankclient.api:http://localhost:9092/bankclient/ben}")
    String benapi;

    @GetMapping("/register")
    public void register()
    {        
    	UserEntity user=new UserEntity();
		
		user.setAddress("mumbai1");
		user.setUserName("roshan1");
		user.setUserId(12345); user.setPassword("1234561");
		user.setEmailId("roshan1@gmail.com");user.setMobile(1254878115);
    	 ResponseEntity<String> resp = restTemplate.getForEntity(bankclientApi,String.class,user);

        System.out.println(resp);
    }
    
    @GetMapping("/account")
    public void getAccountList() {
    	
    	long userid=1;
    	 
    	ResponseEntity<AccountEntity> resp = restTemplate.getForEntity(bankclientApi,AccountEntity.class,userid);

         System.out.println(resp);
    }
    
    public void reqPay()
    {        
    	TransactionEntity txn =new TransactionEntity();
    	
    	txn.setTransactionId(12345);
    	txn.setUserId(1);
    	txn.setTransactionDate("22/06/2020");
    	txn.setTransactionRefNo("TXN001234567890");
    	txn.setPayerAccount("SBIB00123455");
    	txn.setPayerAccountType("SAVING");
    	txn.setPayerIfsc("SBIB00");
    	txn.setPayerAmount("10000");
    	
    	txn.setPayeeAccount("PUN00012344433");
    	txn.setPayeeAccountType("SAVING");
    	txn.setPayeeIfsc("PUB000");
    	txn.setPayeeAmount("10000");
    	
    	
    	 ResponseEntity<String> resp = restTemplate.getForEntity(bankclientApi,String.class,txn);

        System.out.println(resp);
    }
    
    public void addBeneficiary()
    {        
    	BeneficiaryEntity ben = new BeneficiaryEntity();
    	ben.setBenId(12345);
    	ben.setUserId(1);
    	ben.setBenAccount("PUN00012344433");
    	ben.setBenAccountType(BenAccountType.SAVING.toString());
    	ben.setBenBankBranch("Mumbai");
    	ben.setBenBankName("PNB");
    	ben.setBenIfsc("PUB000");
    	
    	
    	 ResponseEntity<String> resp = restTemplate.getForEntity(bankclientApi,String.class,ben);

        System.out.println(resp);
    }
}

